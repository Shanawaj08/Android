# Android-Voting-System
Mobile Phone Voting Application for CS1631 at the University of Pittsburgh
